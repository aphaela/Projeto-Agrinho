const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

const glow=$(".cursor-glow");
window.addEventListener("mousemove",e=>{glow.style.left=e.clientX+"px";glow.style.top=e.clientY+"px"});

const obs=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.12});
$$(".reveal").forEach(e=>obs.observe(e));

$("#mode").onclick=()=>{document.body.classList.toggle("dark");$("#mode").textContent=document.body.classList.contains("dark")?"☾":"☼"};

const points={
 solo:{title:"Solo vivo",text:"O solo é um sistema vivo. Cobertura vegetal, rotação de culturas e matéria orgânica ajudam a proteger sua estrutura e fertilidade.",fact:"Conservar o solo significa proteger a base da produção das próximas safras."},
 agua:{title:"Água protegida",text:"Nascentes, matas ciliares e sistemas de irrigação eficiente ajudam a conservar quantidade e qualidade da água.",fact:"Água bem manejada beneficia a propriedade, a comunidade e os ecossistemas."},
 dados:{title:"Dados no campo",text:"Sensores, mapas e observação permitem aplicar recursos com maior precisão e identificar problemas antes que eles cresçam.",fact:"Tecnologia sustentável é tecnologia usada para tomar decisões melhores."},
 vida:{title:"Biodiversidade",text:"Vegetação nativa, polinizadores e diferentes formas de vida fazem parte do equilíbrio da paisagem rural.",fact:"Uma propriedade não existe isolada: ela integra uma rede de relações ecológicas."}
};
$$(".hotspot").forEach(b=>b.onclick=()=>{
  $$(".hotspot").forEach(x=>x.classList.remove("active"));b.classList.add("active");
  const p=points[b.dataset.point];$("#pointTitle").textContent=p.title;$("#pointText").textContent=p.text;$("#pointFact").textContent=p.fact;
});

const systems={
 solo:["SOLO","Onde tudo começa.","Rotação de culturas, cobertura do solo e matéria orgânica são caminhos para pensar produtividade no longo prazo.","Pesquise sobre plantio direto e rotação de culturas."],
 agua:["ÁGUA","Cada gota tem um caminho.","Proteger nascentes e reduzir perdas na irrigação aproxima eficiência e conservação.","Observe hoje onde sua casa ou escola desperdiça água."],
 tech:["TECNOLOGIA","Dados viram decisões.","Agricultura de precisão usa informação para direcionar recursos e reduzir intervenções desnecessárias.","Pense em um problema do campo que um sensor poderia ajudar a medir."],
 bio:["BIODIVERSIDADE","Mais vida é equilíbrio.","Polinizadores, vegetação nativa e corredores ecológicos ajudam a manter processos naturais.","Descubra quais polinizadores existem na sua região."]
};
function openModal(a){$("#modalTag").textContent=a[0];$("#modalTitle").textContent=a[1];$("#modalText").textContent=a[2];$("#modalTip").textContent=a[3];$("#modal").classList.remove("hidden")}
$$("[data-system]").forEach(b=>b.onclick=()=>openModal(systems[b.dataset.system]));
$("#close").onclick=()=>$("#modal").classList.add("hidden");
$("#modal").onclick=e=>{if(e.target.id==="modal")$("#modal").classList.add("hidden")};
$("#manifesto").onclick=()=>openModal(["MANIFESTO","Produzir é cuidar.","Um agro forte depende de recursos naturais bem manejados, conhecimento, inovação e pessoas. Sustentabilidade não é parar de produzir: é produzir de um jeito que permita continuar.","O futuro não é um lugar para onde vamos. É algo que construímos com cada escolha."]);

const solutionText={
 "Rotacione culturas":["CAMPO","Rotacione culturas","Alternar espécies pode diversificar o uso do solo e contribuir para seu manejo.","Comece pesquisando por que a diversidade de culturas é importante."],
 "Proteja a água":["CAMPO","Proteja a água","Conservar nascentes, matas ciliares e usar irrigação eficiente ajuda a reduzir perdas.","Escolha uma fonte de água perto de você e descubra como ela é protegida."],
 "Use dados":["TECNOLOGIA","Use dados","Sensores, mapas e observação transformam informações em decisões mais precisas.","Pergunte: qual dado seria útil antes de tomar uma decisão?"],
 "Consuma melhor":["CASA","Consuma melhor","Planejar compras, evitar desperdício e reaproveitar materiais conectam nossas escolhas domésticas ao meio ambiente.","Antes de comprar, pergunte se realmente precisa."],
 "Automatize com propósito":["TECNOLOGIA","Automatize com propósito","Tecnologia vale quando resolve um problema real e torna um processo mais eficiente.","Inovação começa com uma boa pergunta."],
 "Abra espaço para a vida":["CAMPO","Abra espaço para a vida","Vegetação nativa e ambientes diversos podem favorecer funções ecológicas e biodiversidade.","Observe quantos tipos de plantas existem no caminho até sua escola."]
};
$$(".action-card button").forEach(b=>b.onclick=()=>openModal(solutionText[b.parentElement.querySelector("h3").textContent]));

$$(".solution-filter button").forEach(b=>b.onclick=()=>{
  $$(".solution-filter button").forEach(x=>x.classList.remove("active"));b.classList.add("active");
  const f=b.dataset.filter;
  $$(".action-card").forEach(c=>c.classList.toggle("hide",f!=="all"&&c.dataset.cat!==f));
});

let state={prod:70,nature:70,resource:70,step:0};
const decisions=[
 {q:"Uma área está com baixa umidade. O que você faz?",a:[["Instalar monitoramento e irrigar somente onde necessário.",[8,4,-5]],["Irrigar toda a área por precaução.",[6,-8,-15]],["Não fazer nada e esperar.",[-8,2,0]]]},
 {q:"A produtividade aumentou, mas a biodiversidade caiu. Qual é a prioridade?",a:[["Criar áreas de vegetação e corredores ecológicos.",[2,12,-2]],["Expandir a área de produção.",[10,-15,-3]],["Ignorar: produtividade é o principal.",[7,-12,0]]]},
 {q:"Você precisa escolher uma nova tecnologia.",a:[["Sensor que mede umidade e nutrientes.",[7,5,-4]],["Máquina maior, sem monitoramento.",[10,-5,-10]],["Nenhuma: tecnologia nunca ajuda.",[-2,0,0]]]},
 {q:"Chegou a hora de planejar a próxima safra.",a:[["Rotacionar culturas e revisar os dados da propriedade.",[7,8,4]],["Repetir exatamente o mesmo plano.",[4,-5,-3]],["Usar mais insumos para garantir produção.",[9,-10,-12]]]}
];
function renderDecision(){
 const d=decisions[state.step];$("#round").textContent=`DECISÃO ${state.step+1} / 4`;$("##decision");
 $("#decision").textContent=d.q;
 $("#choices").innerHTML=d.a.map((x,i)=>`<button class="choice" data-i="${i}">${x[0]}</button>`).join("");
 $$(".choice").forEach(b=>b.onclick=()=>choose(+b.dataset.i));
}
function clamp(n){return Math.max(0,Math.min(100,n))}
function updateMeters(){
 [["prod", "#prodNum","#prodBar"],["nature","#natureNum","#natureBar"],["resource","#resourceNum","#resourceBar"]].forEach(([k,n,b])=>{state[k]=clamp(state[k]);$(n).textContent=Math.round(state[k]);$(b).style.width=state[k]+"%"})
}
function choose(i){
 const vals=decisions[state.step].a[i][1];state.prod+=vals[0];state.nature+=vals[1];state.resource+=vals[2];updateMeters();state.step++;
 if(state.step<decisions.length)setTimeout(renderDecision,350);else{
   $("#choices").classList.add("hidden");$("#decision").classList.add("hidden");
   const avg=(state.prod+state.nature+state.resource)/3;
   let title=avg>=78?"🌱 Guardião do futuro":avg>=62?"🌾 Produtor consciente":"🔎 Explorador em evolução";
   $("#gameEnd").classList.remove("hidden");$("#gameEnd").innerHTML=`<strong>${title}</strong><br>Seu equilíbrio final foi de ${Math.round(avg)}/100. ${avg>=78?"Você conseguiu manter produção e natureza caminhando juntas!":"Cada decisão ensina algo. O equilíbrio é construído ao longo do tempo."}<br><br><button class="btn primary" onclick="location.reload()">Jogar novamente ↻</button>`;
 }
}
renderDecision();updateMeters();

$$(".commitment button").forEach(b=>b.onclick=()=>{
 const msgs={agua:"Você escolheu começar pela água. Observe seus hábitos e procure uma forma concreta de evitar desperdícios.",solo:"Você escolheu o solo. Lembre-se: cuidar da base é cuidar do futuro da produção.",desperdicio:"Você escolheu reduzir desperdícios. Aproveitar melhor os recursos também é uma forma de inovação.",conhecimento:"Você escolheu compartilhar conhecimento. Uma ideia só transforma quando circula."};
 $("#commitResult").textContent="✦ "+msgs[b.dataset.commit];
});
